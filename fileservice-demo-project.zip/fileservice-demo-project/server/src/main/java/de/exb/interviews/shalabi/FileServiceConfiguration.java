package de.exb.interviews.shalabi;

import io.dropwizard.Configuration;

public class FileServiceConfiguration extends Configuration {

}
