package de.exb.interviews.shalabi.resources;

import javax.ws.rs.Path;

@Path("/api/v1/files")
public class FileServiceResource {

}
